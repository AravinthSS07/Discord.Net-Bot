﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Discord;
using Discord.Commands;
using Discord.WebSocket;
using Microsoft.Extensions.DependencyInjection;

namespace Techno_Bot.Module
{
    public class Commands : ModuleBase<SocketCommandContext>
    {
        [Command("hi")]
        [Alias("hello")]
        public async Task Hi()
        {
            await ReplyAsync("Hello!");
        }

        [Command("tick")]
        public async Task Tick()
        {
            await ReplyAsync("Tack");
        }

        [Command("ban")]
        [RequireUserPermission(GuildPermission.BanMembers, ErrorMessage = "You don't have permission to ban members ``ban_member``!")]
        public async Task BanMember(IGuildUser user = null, [Remainder] string reason = null)
        {
            if (user == null)
            {
                await ReplyAsync("Please speacify a user!");
                return;
            }
            if (reason == null) reason = "Not specified";

            await Context.Guild.AddBanAsync(user, 1, reason);

            var EmbedBuilder = new EmbedBuilder()
                .WithDescription($":white_check_mark:{user.Mention} was banned\n**Reason** {reason}")
                .WithFooter(footer =>
                {
                    footer
                    .WithText("User Ban Log")
                    .WithIconUrl("http://www.fastkashmir.com/wp-content/uploads/2017/03/ban-2.png");

                });
            Embed embed = EmbedBuilder.Build();
            await ReplyAsync(embed: embed);

            ITextChannel logChannel = Context.Client.GetChannel(743741286674202726) as ITextChannel;
            var EmbedBuilderLog = new EmbedBuilder()
                .WithDescription($"{user.Mention} was banned\n**Reason** {reason}\n **Moderator**{Context.User.Mention}")
                .WithFooter(footer =>
                {
                    footer
                    .WithText("User Ban Log")
                    .WithIconUrl("http://www.fastkashmir.com/wp-content/uploads/2017/03/ban-2.png");

                });
            Embed embedLog = EmbedBuilderLog.Build();
            logChannel.SendMessageAsync(embed: embedLog);
        }

        [Command("unban")]
        [RequireUserPermission(GuildPermission.BanMembers, ErrorMessage = "You don't have permission to unban members ``unban_member``!")]
        public async Task UnBanMember(IGuildUser user = null, [Remainder] string reason = null)
        {
            if (user == null)
            {
                await ReplyAsync("Please speacify a user!");
                return;
            }
            if (reason == null) reason = "Not specified";

            await Context.Guild.RemoveBanAsync(user);
        }

        [Command("skick")]
        [RequireUserPermission(GuildPermission.BanMembers, ErrorMessage = "You don't have permission to kick members ``kick_member``!")]
        public async Task KickMember(IGuildUser user = null, [Remainder] string reason = null)
        {
            if (user == null)
            {
                await ReplyAsync("Please speacify a user!");
                return;
            }
            if (reason == null) reason = "Not specified";

            await user.KickAsync(reason);
        }

        [Command("kick")]
        public async Task KickStatement(IGuildUser user = null, [Remainder] string reason = null)
        {
            if (user == null)
            {
                await ReplyAsync("Please specify a user!");
                return;
            }
            if (reason == null) reason = $"you we're kicked on your butt by {Context.User.Mention}";

            await user.SendMessageAsync(reason);
        }

        [Command("dog")]
        public async Task Dog(IGuildUser user = null, [Remainder] string reason = null)
        {
            if (user == null)
            {
                await ReplyAsync("Please specify a user");
                return;
            }
            if (reason == null) reason = $"{Context.User.Mention} asked me to send you a dog photo\n https://www.bing.com/th/id/OGC.97919774cd7c7944138fc6c8ebbc508c?pid=1.7&rurl=https%3a%2f%2fmedia.tenor.com%2fimages%2f97919774cd7c7944138fc6c8ebbc508c%2ftenor.gif&ehk=SwWNVJBRljtFuLL%2fqQ%2bEI8wC2fkfa3tp9W9S2E8fZuE%3d";

            await user.SendMessageAsync(reason);
        }

        [Command("flip")]
        public async Task Flip(IGuildUser user = null, [Remainder] string type = null)
        {
            if (type == "heads")
            {
                await ReplyAsync("no its tails");
                return;
            }
            if (type == "tails")
            {
                await ReplyAsync("oh boy its heads");
                return;
            }
        }
        [Command("meme")]
        public async Task Meme()
        {
            await ReplyAsync("https://tenor.com/view/nerd-gif-4942427");
        }

        [Command("hardwarenews")]
        public async Task Hardwarenews()
        {
            await ReplyAsync("https://www.pcgamer.com/hardware/");
        }

        [Command("dm")]
        public async Task Dm(IGuildUser user = null, [Remainder] string chat = null)
        {
            if (user == null)
            {
                await ReplyAsync("Please specify whom you want to dm");
                return;
            }
            if (chat == null) chat = $"{Context.User.Mention} just dm you nothing as the person to send somthing";

            await user.SendMessageAsync(chat);
        }

        [Command("help")]
        public async Task Help()
        {
            await ReplyAsync("Hi I am Techno Bot and my prefix is '!'\nmy commnads are\nhi(!hi)\nhello(!hello)\ntick(just for fun '!tick')\nkick(prank you friends by kicking '!kick <mention> <reason>')\nflip(flip a coin '!flip @Techno Bot')\ndog(send your friends dog photo '!dog <mention user>')\nhardwarenews(latest news about hardwares '!hardwarenews')\nmeme(get memes only 1 per day '!meme')\ndm(send direct message using the bot'!dm <mention user><chat>')");
        }

        [Command("purge")]
        public async Task Purge(int max)
        {

            var messages = Context.Channel.GetMessagesAsync(max).Flatten();
            foreach (var h in await messages.ToArrayAsync())
            {
                await this.Context.Channel.DeleteMessageAsync(h);
            }
        }
        
        public async Task Announce()
        {
            DiscordSocketClient _client = new DiscordSocketClient();
            ulong id = 750644910440448033;
            var chnl = _client.GetChannel(id) as IMessageChannel;
            await chnl.SendMessageAsync("welcome to the coders");
        }

        [Command("fuck")]
        public async Task Fuck(IGuildUser user = null, [Remainder] string reason = null)
        {
            if (user == null)
            {
                await ReplyAsync("Please specify a user");
                return;
            }
            if (reason == null) reason = $"{Context.User.Mention} just send you :middle_finger_tone4:";

            await user.SendMessageAsync(reason);
        }

        [Command("bye")]
        public async Task Bye()
        {
            await ReplyAsync($"Bye {Context.User.Mention}");
        }

    }

}
